# fontBomb-no-banner
Removes the loaded banner from fontBomb.

Make a new bookmark with <br>
`javascript:(function () {var s = document.createElement('script');s.setAttribute('src', 'https://raw.githubusercontent.com/CaptainMudkip1/fontBomb-no-banner/main/FontBomb.js');document.body.appendChild(s);}());` <br>
as the URL to use it.
