# Echo-Array-PHP
A function to echo an array's contents in php.
# Usage 
* Type `include 'function.php'` at the start of your php code.
* Edit the php.ini file and look for the line `auto_prepend_file`. Type the path to the function.php file there. This method will act like you typed `include function.php` at the start of every php code file.
- - - -
The function that this creates is `EchoArray()`. The array/array vaiable goes inside the parentheses.
